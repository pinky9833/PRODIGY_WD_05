async function getWeatherByLocation() {
    const location = document.getElementById('location').value;
    const apiKey = '465cc7fe9825fe8044d0fe18a1899777';  
    const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${location}&appid=${apiKey}&units=metric`;

    document.getElementById('weather-data').classList.add('hidden');
    document.getElementById('loading-spinner').classList.remove('hidden');

    try {
        const response = await fetch(apiUrl);
        if (!response.ok) {
            throw new Error('Network response was not ok ' + response.statusText);
        }
        const weatherData = await response.json();
        displayWeatherData(weatherData);
    } catch (error) {
        console.error('There has been a problem with your fetch operation:', error);
        alert('Could not fetch weather data. Please try again.');
    } finally {
        document.getElementById('loading-spinner').classList.add('hidden');
    }
}

function displayWeatherData(data) {
    document.getElementById('location-name').innerText = `Location: ${data.name}`;
    document.getElementById('temperature').innerText = `Temperature: ${data.main.temp}°C`;
    document.getElementById('conditions').innerText = `Conditions: ${data.weather[0].description}`;
    document.getElementById('humidity').innerText = `Humidity: ${data.main.humidity}%`;
    document.getElementById('wind-speed').innerText = `Wind Speed: ${data.wind.speed} m/s`;

    const iconCode = data.weather[0].icon;
    document.getElementById('weather-icon').src = `http://openweathermap.org/img/wn/${iconCode}.png`;
    document.getElementById('weather-icon').alt = data.weather[0].description;

    document.getElementById('weather-data').classList.remove('hidden');
}
